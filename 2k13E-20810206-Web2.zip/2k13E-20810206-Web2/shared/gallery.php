<div class="grid">
    <div class="grid-item">
        <img src="img/gallery-img-23-01.jpg" alt="Image">
        <div><b>Photo Name</b></div>
        <div>Price: $2.99</div>
    </div>
    <div class="grid-item"><img src="img/gallery-img-11-01.jpg" alt="Image">
        <div><b>Photo Name</b></div>
        <div>Price: $2.99</div>
    </div>
    <div class="grid-item"><img src="img/gallery-img-12-01.jpg" alt="Image">
        <div><b>Photo Name</b></div>
        <div>Price: $2.99</div>
    </div>
    <div class="grid-item"><img src="img/gallery-img-11-02.jpg" alt="Image">
        <div><b>Photo Name</b></div>
        <div>Price: $2.99</div>
    </div>
    <div class="grid-item"><img src="img/gallery-img-12-02.jpg" alt="Image"></div>
    <div class="grid-item"><img src="img/gallery-img-23-02.jpg" alt="Image"></div>
    <div class="grid-item"><img src="img/gallery-img-11-03.jpg" alt="Image"></div>
    <div class="grid-item"><img src="img/gallery-img-23-03.jpg" alt="Image"></div>
</div>