<section id="welcome" class="tm-content-box tm-banner margin-b-15">
    <div class="tm-banner-inner">
        <i class="fa fa-film fa-4x margin-b-40"></i>
        <h1 class="tm-banner-title">Mason</h1>
        <p class="tm-banner-subtitle">new HTML template</p>
    </div>
</section>