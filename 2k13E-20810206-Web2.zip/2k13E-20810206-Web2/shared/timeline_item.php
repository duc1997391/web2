
<div class="row mb-5">
    <div class="media tm-flexbox-ie-fix tm-width-ie-fix">
        <div class="tm-media-img-container">
            <div class="text-center pt-31 pb-31 tm-timeline-date tm-bg-pink"><?php echo $SV->?></div>
            <img class="d-flex img-fluid" src="img/610x610-01.jpg" alt="Generic placeholder image">
        </div>

        <div class="media-body tm-flexbox-ie-fix tm-width-ie-fix tm-bg-light-gray">
            <div class="p-5">
                <h2 class="mb-4 mt-0 tm-blue-text tm-timeline-item-title">ID - Họ tên Employee</h2>
                <p class="mb-4">
                    About Me của Employee
                </p>

                <a href="#" class="btn btn-primary tm-button-rounded tm-button-pink tm-button-no-border tm-button-normal tm-button-timeline">Read More</a>
            </div>
        </div>
    </div>
</div> <!-- row -->